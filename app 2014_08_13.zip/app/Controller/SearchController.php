<?php
class SearchController extends AppController{

	public function index(){

		// debug($this->Search->find('all', array(
		// 	'fields'	 => array('Search.id', 'Search.name'),
		// 	'conditions' => array('Search.name like' => '%3%')
		// 	)));
		// 	die ();

	}

	public function research(){
		
	}

}