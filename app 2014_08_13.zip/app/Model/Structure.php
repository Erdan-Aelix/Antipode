<?php
class Structure extends AppModel{

	
	
}