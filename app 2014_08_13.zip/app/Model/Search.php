<?php
class Search extends AppModel{

	
	
}